<?php
/**
 * Created by www.hidove.cn.
 * User: YuSheng
 * Date: 2018/6/30
 * Time: 9:40
 */

?>
<div class="container">
    <div id="footer">
        <p class="text-center">Copyright © <?php echo date('Y') ?> - <a href=""
                                                                        target="_blank">余生</a> Corporation,All Rights
            Reserved
        </p>
        <p class="text-center">本站提供的最新电影和电视剧资源均系收集于各大视频网站,本站只提供web页面服务,并不提供影片资源存储,也不参与录制、上传<br/>
            若本站收录的节目无意侵犯了贵司版权，请给网页底部邮箱地址来信,我们会及时处理和回复,谢谢。<br/>
            管理员邮箱：<a href="i@abcyun.cc">i@abcyun.cc</a>
        </p>
    </div>
</div>
<div style="display:none">
    <!-- 统计代码 -->
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?54d628101e1529fb25b0e3381859d940";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_1274488825'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s13.cnzz.com/z_stat.php%3Fid%3D1274488825%26show%3Dpic' type='text/javascript'%3E%3C/script%3E"));</script>
</div>