<?php
$configs = array(
    'name' => 'MVideo', #网站标题
    'subtitle' => '自动采集更新全网视频,免费看VIP视频,支持在线播放', #副标题
    'keywords' => 'Hidove,MVideo', #关键字
    'description' => 'MVideo自动采集影视系统,免费看全网视频。', #描述
    'template' => 'MVideo', #模板
    'Sensitive' => true, #是否屏蔽敏感资源,默认true
    'Sensitive_password' => "22008", #敏感资源密码
);
?>
